package com.example.the_clicker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView mainText;
    ImageButton mainBtn1;
    ImageButton mainBtn2;
    ImageButton mainBtn;

    private long score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainText = (TextView) findViewById(R.id.mainTxt);
        mainBtn1 = (ImageButton) findViewById(R.id.main_btn1);
        mainBtn2 = (ImageButton) findViewById(R.id.main_btn2);
        mainBtn = (ImageButton) findViewById(R.id.main_btn);

        mainBtn1.setOnClickListener(clickListener1);
        mainBtn2.setOnClickListener(clickListener2);
        mainBtn.setOnClickListener(clickListener);
    }

    View.OnClickListener clickListener1 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            score ++;

            if (score%10==2 && score!=12 || score%10==3 && score!=13 || score%10==4 && score!=14){
                String s = "Кликов: " + score + " раза";
                mainText.setText(s.toCharArray(),0, s.length());}
            else{
                String s = "Кликов: " + score + " раз";
                mainText.setText(s.toCharArray(),0, s.length());}
        }
    };

    View.OnClickListener clickListener2 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            score --;

            if (score%10==-2 && score!=-12 || score%10==-3 && score!=-13 || score%10==-4 && score!=-14){
                String s = "Кликов: " + score + " раза";
                mainText.setText(s.toCharArray(),0, s.length());}
            else{
                String s = "Кликов: " + score + " раз";
                mainText.setText(s.toCharArray(),0, s.length());}
        }
    };

    View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            score = 0;
            String s = "Кликов: " + score;
            mainText.setText(s.toCharArray(),0, s.length());
        }
    };
}


